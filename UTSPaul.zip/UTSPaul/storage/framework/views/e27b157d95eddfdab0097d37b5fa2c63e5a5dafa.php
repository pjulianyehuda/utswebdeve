
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 50px; margin-bottom: 50px">
        <div class="row">
            <h1 class="col">Insert mobil Data</h1>
        </div>
        <div class="row">
            <div class="col">
            <form action="<?php echo e(route('brandmobil.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Brand Mobil:</label>
                        <input type="text" class="form-control" name="brandmobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <!-- <div class="form-group">
                        <label>Nama Mobil:</label>
                        <input class="form-control" name="nama_mobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">

                    </div> -->
                    
                    <!-- <div class="form-group">
                        <label>Kapasitas Mesin:</label>
                        <select class="custom-select" name="brandmobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                            <?php $__currentLoopData = $brandmobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandmobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brandmobil->id); ?>"><?php echo e($brandmobil->nama_brandmobil . ' (' . $brandmobil->mobil .')'); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> -->
                    <!-- <div class="form-group">
                        <label for="tanggal">Major:</label>
                        <input class="form-control" name="jurusan" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <div class="form-group">
                        <label>Birth Date:</label>
                        <input type="date" class="form-control" name="tanggal_lahir" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <div class="form-group">
                        <label>Gender:</label><br>
                        <input type="radio" class="form_control" id="pria" name="jenis_kelamin" value="Pria" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                        <label for="pria">Male</label><br>
                        <input type="radio" class="form_control" id="wanita" name="jenis_kelamin" value="Wanita" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                        <label for="wanita">Female</label><br>
                    </div> -->
                    <button type="submit" class="btn btn-primary" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UTSPaul\resources\views/brandmobil/addbrandmobil.blade.php ENDPATH**/ ?>