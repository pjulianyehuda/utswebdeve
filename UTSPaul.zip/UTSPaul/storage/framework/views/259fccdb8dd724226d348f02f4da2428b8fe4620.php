
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 20px;">
    <div class="row">
        <h1 class="col">List Data</h1>
    </div>
    <div>

    </div>
    <div class="row">
        <div class="col-md-2 offset-md-10">
        <a href="<?php echo e(route('brandmobil.create')); ?>" class="btn btn-primary btn-block" role="button"
                   aria-pressed="true">Tambah</a>
        </div>
    </div>
    <div class="row" style="margin-top: 30px;">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Brand Mobil</th>
                    <th scope="col">Mobil</th>
                    <th scope="col">Kapasitas Mesin</th>
                    <th scope="col">Transmisi</th>
                    <th scope="col">Tenaga</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $brandmobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandmobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('brandmobil.edit',$brandmobil)); ?>"><?php echo e($brandmobil->brandmobil); ?></a></td>
                    <td><?php echo e($brandmobil->mobil); ?></td>
                    <td><?php echo e($brandmobil->kapasitasmesin); ?></td>
                    <td><?php echo e($brandmobil->transmisi); ?></td>
                    <td><?php echo e($brandmobil->tenaga); ?></td>
                    
                    <td>
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UTSPaul\resources\views/brandmobil/index.blade.php ENDPATH**/ ?>