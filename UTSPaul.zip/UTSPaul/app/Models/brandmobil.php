<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class brandmobil extends Model
{
    use HasFactory;
    protected $fillable = ['brandmobil','mobil','kapasitasmesin','transmisi','tenaga',''];
}
