@extends('layouts.app')
@section('content')
    <div class="container" style="margin-top: 50px; margin-bottom: 50px">
        <div class="row">
            <h1 class="col">Insert mobil Data</h1>
        </div>
        <div class="row">
            <div class="col">
            <form action="{{ route('mobil.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label>Mobil:</label>
                        <input type="text" class="form-control" name="mobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <div class="form-group">
                        <label>Nama Mobil:</label>
                        <input class="form-control" name="nama_mobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">

                    </div> 
                    
                    <div class="form-group">
                        <label>Kapasitas Mesin:</label>
                        <select class="custom-select" name="mobil" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Transmisi:</label>
                        <input class="form-control" name="jurusan" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <div class="form-group">
                        <label>Tenaga:</label>
                        <input type="date" class="form-control" name="tanggal_lahir" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">
                    </div>
                    <!-- <div class="form-group">
                        <label>:</label><br>
                        
                    </div> -->
                    <button type="submit" class="btn btn-primary" onmouseover="this.style.boxShadow='0px 0px 15px LightSkyBlue'" onmouseout="this.style.boxShadow='0px 0px 0px LightSkyBlue'">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection
