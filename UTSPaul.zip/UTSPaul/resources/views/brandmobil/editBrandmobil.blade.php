@extends('layouts.app')
@section('content')
<div class="container" style="margin-top: 50px; margin-bottom: 50px">
    <div class="row">
        <h1 class="col">Edit Data Mobil</h1>
    </div>
    <div class="row">
        <div class="col">
            <form action="{{ route('brandmobil.update'),$brandmobil }}" method="post">
                @csrf
                <input type="hidden" name="_method" value="PATCH">
                <div class="form-group">
                    <label> Nama Mobil:</label>
                    <input type="text" class="form-control" name="nama_mobil" value="{{ $mobil->nama_mobil }}">
                </div>
                <div class="form-group">
                    <label>Kapasitas Mesin:</label>
                    <input class="form-control" value="{{ $mobil->kapasitasmesin }}" disabled>
                </div>
                <div class="form-group">
                    <label for="tanggal">Transmisi:</label>
                    <input class="form-control" value="{{ $mobil->transmisi }}" disabled>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
@endsection