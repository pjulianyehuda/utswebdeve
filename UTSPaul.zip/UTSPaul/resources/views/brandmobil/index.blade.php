@extends('layouts.app')
@section('content')
<div class="container" style="margin-top: 20px;">
    <div class="row">
        <h1 class="col">List Data</h1>
    </div>
    <div>

    </div>
    <div class="row">
        <div class="col-md-2 offset-md-10">
        <a href="{{ route('brandmobil.create') }}" class="btn btn-primary btn-block" role="button"
                   aria-pressed="true">Tambah</a>
        </div>
    </div>
    <div class="row" style="margin-top: 30px;">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Brand Mobil</th>
                    <th scope="col">Mobil</th>
                    <th scope="col">Kapasitas Mesin</th>
                    <th scope="col">Transmisi</th>
                    <th scope="col">Tenaga</th>
                    
                </tr>
            </thead>
            <tbody>
                @foreach($brandmobils as $brandmobil)
                <tr>
                    <td><a href="{{ route('brandmobil.edit',$brandmobil)}}">{{ $brandmobil->brandmobil}}</a></td>
                    <td>{{$brandmobil->mobil}}</td>
                    <td>{{$brandmobil->kapasitasmesin }}</td>
                    <td>{{$brandmobil->transmisi }}</td>
                    <td>{{$brandmobil->tenaga }}</td>
                    
                    <td>
                        <form action="" method="post">
                            @csrf
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection